# JavaGame
Simple Battle simulator written in Java with Netbeans GUI as end of year project for APCSA

The jar file within the dist folder needed to be zipped to fit on GitHub. Unzip it to acess the jar file if wanted.
